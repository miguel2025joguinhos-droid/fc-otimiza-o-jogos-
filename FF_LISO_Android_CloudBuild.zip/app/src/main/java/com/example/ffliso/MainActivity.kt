package com.example.ffliso

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import android.os.PowerManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101117)
private val Panel = Color(0xFF1C1D28)
private val Purple = Color(0xFFB69CFF)
private val Muted = Color(0xFFB8B8C7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FFLisoApp(this) }
    }
}

@Composable
fun FFLisoApp(context: Context) {
    var prepared by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ainda não preparado") }
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memory = remember {
        ActivityManager.MemoryInfo().also { activityManager.getMemoryInfo(it) }
    }
    activityManager.getMemoryInfo(memory)
    val availableRamGb = memory.availMem / (1024.0 * 1024.0 * 1024.0)
    val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    val powerSave = powerManager.isPowerSaveMode

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            background = Bg,
            surface = Panel,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("⚡ FF LISO", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
                Text("Preparação de desempenho • sem root", color = Purple, fontSize = 14.sp)
                Text(
                    "Ajuda a preparar o celular para jogar. Não altera a velocidade dos adversários nem garante FPS extra.",
                    color = Muted, fontSize = 13.sp
                )

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("DIAGNÓSTICO", color = Purple, fontWeight = FontWeight.Bold)
                        Metric("RAM disponível (aprox.)", String.format("%.1f GB", availableRamGb))
                        Metric("Economia de bateria", if (powerSave) "Ativada" else "Desativada")
                        Text(
                            "A RAM disponível muda durante o uso. Este valor é uma leitura do Android, não uma medição de FPS.",
                            color = Muted, fontSize = 12.sp
                        )
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("MODO FLUIDEZ", color = Purple, fontWeight = FontWeight.Bold)
                        Text("Checklist seguro antes de abrir o FF:", color = Muted)
                        ChecklistItem("Fechar apps que tu não está usando")
                        ChecklistItem("Deixar o celular esfriar se estiver quente")
                        ChecklistItem("Desativar economia de bateria durante a partida, se isso ajudar no teu aparelho")
                        ChecklistItem("Usar a opção de FPS mais alta que o jogo oferece de forma estável")
                        ChecklistItem("Manter o GG Mouse Pro ativo e testar os comandos")
                        Button(
                            onClick = {
                                prepared = true
                                status = "Checklist concluído. Revise os itens antes de abrir o jogo."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (prepared) "Preparação concluída" else "Preparar para jogar") }
                        Text(status, color = if (prepared) Purple else Muted, fontSize = 12.sp)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("IMPORTANTE", color = Purple, fontWeight = FontWeight.Bold)
                        Text(
                            "O Android não permite que um app comum force o processador no máximo, libere toda a RAM ou encerre outros apps à vontade. O FF LISO não mata processos, não muda arquivos do Free Fire e não pede acessibilidade, VPN, root ou comandos ADB.",
                            color = Muted, fontSize = 13.sp
                        )
                    }
                }
                Text("FF LISO • versão inicial 0.1.0", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 14.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ChecklistItem(text: String) {
    var checked by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = { checked = it })
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}
