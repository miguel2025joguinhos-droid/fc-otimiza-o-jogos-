# FF LISO — Android starter project

Starter source for an Android app that provides safe pre-game checks and basic device diagnostics for Free Fire players using GG Mouse Pro in the background.

## What it does
- Shows an approximate Android-reported available RAM value.
- Shows whether Android battery saver is enabled.
- Provides a user-controlled pre-game checklist.
- Does not kill background processes, modify Free Fire, change network traffic, force FPS, or promise a performance boost.

## Build
1. Install Android Studio and a compatible JDK (Android Studio's bundled JDK is fine).
2. Open this folder as a project.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Run the `app` configuration on an Android device or emulator.

This is source code, not a compiled APK. It has not been built or tested in this environment.


## Gerar APK usando o celular (GitHub Actions)

Este projeto inclui um fluxo de compilação na nuvem. Envie os arquivos do projeto para um repositório GitHub, com o nome de branch `main`. Depois abra a aba **Actions**, escolha **Build FF LISO APK** e toque em **Run workflow** (ou faça um envio de commit para `main`). Quando terminar com sucesso, abra a execução e baixe o artefato **FF-LISO-debug-APK**. Extraia o ZIP baixado para encontrar o APK.

A compilação na nuvem pode falhar se versões de dependências precisarem de ajustes. O APK gerado é uma versão de teste, não uma versão publicada na Play Store. O app inicial é uma base de demonstração e não aumenta FPS nem encerra processos automaticamente.
